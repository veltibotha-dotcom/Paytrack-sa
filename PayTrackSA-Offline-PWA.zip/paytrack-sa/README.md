# PayTrack SA — private offline Android PWA

## Files
- index.html — responsive user interface
- app.js — payment logic, local storage, backups
- sw.js — offline cache
- manifest.webmanifest — install metadata
- icon.svg — app icon

## Publish entirely from a Samsung Android phone
1. Download the ZIP and extract it in Samsung My Files.
2. Create a free GitHub account in Chrome, if necessary.
3. In GitHub, create a new **public** repository named `paytrack-sa` (the code is public; your financial records are NOT included).
4. Select **Add file → Upload files**, upload the five app files from the extracted folder (`index.html`, `app.js`, `sw.js`, `manifest.webmanifest`, `icon.svg`). You do not need to upload README.
5. Go to repository **Settings → Pages**. Under Build and deployment select **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
6. Wait for the GitHub Pages site to publish. Visit `https://YOUR-USERNAME.github.io/paytrack-sa/` in Chrome on the Samsung phone.
7. In Chrome menu (three dots), choose **Add to Home screen → Install** (wording varies). Open the new PayTrack SA icon once online. Thereafter it can work offline.

## Important
- GitHub Pages is free for public repositories; the app's SOURCE CODE is public, not your locally stored bill data.
- The app stores data using localStorage on the specific browser installation. Clearing browser data, uninstalling, or losing your phone may erase it.
- Use **Backup → Export JSON backup** frequently and keep copies outside the phone (e.g. private cloud drive).
- Restoring a backup overwrites the current app data.
- No bank integration, notifications, cloud sync or automatic transfers.
- If you change the repository name, the GitHub Pages URL changes accordingly.
- For best Android installation compatibility, an additional 192px and 512px PNG icon can be added later; SVG works on many Chromium-based browsers but installation prompts vary.
